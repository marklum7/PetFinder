package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.example.myapplication.data.DatabaseHelper
import com.example.myapplication.data.PetPostWithImages

class PetDetailFragment : Fragment() {

    private lateinit var viewPager: ViewPager2
    private lateinit var tvPostType: TextView
    private lateinit var tvPetName: TextView
    private lateinit var tvPetBreed: TextView
    private lateinit var tvPetAge: TextView
    private lateinit var tvPetColor: TextView
    private lateinit var tvSpecialMarks: TextView
    private lateinit var tvDatePosted: TextView
    private lateinit var tvLocation: TextView
    private lateinit var ivContactOwner: ImageView
    
    private lateinit var dbHelper: DatabaseHelper
    private var petPost: PetPostWithImages? = null
    
    companion object {
        private const val ARG_POST_ID = "post_id"
        
        fun newInstance(postId: Long): PetDetailFragment {
            val fragment = PetDetailFragment()
            val args = Bundle()
            args.putLong(ARG_POST_ID, postId)
            fragment.arguments = args
            return fragment
        }
    }
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_pet_detail, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        dbHelper = DatabaseHelper(requireContext())
        
        // Initialize views
        viewPager = view.findViewById(R.id.viewPagerImages)
        tvPostType = view.findViewById(R.id.tvPostTypeDetail)
        tvPetName = view.findViewById(R.id.tvPetNameDetail)
        tvPetBreed = view.findViewById(R.id.tvPetBreedDetail)
        tvPetAge = view.findViewById(R.id.tvPetAgeDetail)
        tvPetColor = view.findViewById(R.id.tvPetColorDetail)
        tvSpecialMarks = view.findViewById(R.id.tvSpecialMarksDetail)
        tvDatePosted = view.findViewById(R.id.tvDatePostedDetail)
        tvLocation = view.findViewById(R.id.tvLocationDetail)
        
        // Load pet post data
        val postId = arguments?.getLong(ARG_POST_ID) ?: -1
        if (postId != -1L) {
            loadPetPost(postId)
        }

    }
    
    private fun loadPetPost(postId: Long) {
        val post = dbHelper.getPetPostById(postId)
        if (post != null) {
            petPost = post
            displayPetPost()
        }
    }
    
    private fun displayPetPost() {
        petPost?.let { post ->
            // Set basic info
            tvPostType.text = post.petPost.postType
            tvPetName.text = post.petPost.petName ?: "Не указано"
            tvPetBreed.text = post.petPost.petBreed
            tvPetAge.text = post.petPost.petAge ?: "Не указан"
            tvPetColor.text = post.petPost.petColor
            tvSpecialMarks.text = post.petPost.specialMarks ?: "Не указаны"
            tvDatePosted.text = post.petPost.datePosted
            tvLocation.text = post.petPost.locationAddress
            
            // Setup image slider
            if (post.images.isNotEmpty()) {
                val imageAdapter = PetImageAdapter(post.images)
                viewPager.adapter = imageAdapter
            }
        }
    }
}