package com.example.myapplication

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.DatabaseHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class PetListFragment : Fragment() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var petAdapter: PetAdapter
    private lateinit var spinnerPostType: Spinner
    private lateinit var spinnerBreed: Spinner
    private lateinit var spinnerColor: Spinner
    private lateinit var fabAddPost: ExtendedFloatingActionButton  // вместо FloatingActionButton
    
    private lateinit var dbHelper: DatabaseHelper
    private val currentFilters = mutableMapOf<String, String>()
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_pet_list, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        dbHelper = DatabaseHelper(requireContext())
        
        // Инициализация views
        recyclerView = view.findViewById(R.id.recyclerViewPets)
        spinnerPostType = view.findViewById(R.id.spinnerPostType)
        spinnerBreed = view.findViewById(R.id.spinnerBreed)
        spinnerColor = view.findViewById(R.id.spinnerColor)
        fabAddPost = view.findViewById(R.id.fabAddPost)


        // Настройка RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        petAdapter = PetAdapter(
            emptyList(),
            { postId ->
                // Переход к деталям объявления
                val bundle = Bundle().apply {
                    putLong("post_id", postId)
                }
                findNavController().navigate(R.id.action_petListFragment_to_petDetailFragment, bundle)
            },
            false,  // isAdmin parameter
            null    // onDeleteClick parameter
        )
        recyclerView.adapter = petAdapter
        
        // Настройка плавающей кнопки
       // fabAddPost.setOnClickListener {
       //     findNavController().navigate(R.id.action_petListFragment_to_newPetPostFragment)
        //}

        fabAddPost.setOnClickListener {
             findNavController().navigate(R.id.action_petListFragment_to_newPetPostFragment)
        }
        val btnAdminPanel = view.findViewById<MaterialButton>(R.id.btnAdminPanel)
    
        // Получаем информацию о пользователе из ActivityMain
        val mainActivity = activity as MainActivity
        val userRole = mainActivity.getUserRole()
        
        // Показываем кнопку только для администраторов
        btnAdminPanel.visibility = if (userRole == DatabaseHelper.ROLE_ADMIN) View.VISIBLE else View.GONE
        btnAdminPanel.setOnClickListener {
            findNavController().navigate(R.id.adminPanelFragment)
        }
        
        val filterHeaderLayout = view.findViewById<LinearLayout>(R.id.filterHeaderLayout)
        val filtersContainer = view.findViewById<LinearLayout>(R.id.filtersContainer)
        val arrowIcon = view.findViewById<ImageView>(R.id.arrowIcon)
        
        // Фильтры скрыты по умолчанию
        filtersContainer.visibility = View.GONE
        arrowIcon.setImageResource(R.drawable.ic_arrow_down)
        
        // Обработка нажатия на заголовок фильтров
        filterHeaderLayout.setOnClickListener {
            // Переключаем видимость
            if (filtersContainer.visibility == View.VISIBLE) {
                // Скрываем фильтры
                filtersContainer.visibility = View.GONE
                arrowIcon.setImageResource(R.drawable.ic_arrow_down)
            } else {
                // Показываем фильтры
                filtersContainer.visibility = View.VISIBLE
                arrowIcon.setImageResource(R.drawable.ic_arrow_up)
            }
        }
        
        // Настройка спиннеров
        setupSpinners()

    }
    
    private fun setupSpinners() {
        // Настройка спиннера типа объявления
        val postTypes = resources.getStringArray(R.array.post_types)
        val postTypeAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, postTypes)
        postTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPostType.adapter = postTypeAdapter
        spinnerPostType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val postType = parent?.getItemAtPosition(position).toString()
                    currentFilters["postType"] = postType
                } else {
                    currentFilters.remove("postType")
                }
                loadPosts()
            }
            
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // Настройка спиннера породы
        val breeds = listOf("Все") + dbHelper.getAllBreeds()
        val breedAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, breeds)
        breedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerBreed.adapter = breedAdapter
        spinnerBreed.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val breed = parent?.getItemAtPosition(position).toString()
                    currentFilters["breed"] = breed
                } else {
                    currentFilters.remove("breed")
                }
                loadPosts()
            }
            
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // Настройка спиннера цвета
        val colors = listOf("Все", "Черный", "Белый", "Коричневый", "Серый", "Рыжий", "Пестрый")
        val colorAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, colors)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerColor.adapter = colorAdapter
        spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val color = parent?.getItemAtPosition(position).toString()
                    currentFilters["color"] = color
                } else {
                    currentFilters.remove("color")
                }
                loadPosts()
            }
            
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }
    
    private fun loadPosts() {
        val posts = dbHelper.getAllPetPosts(if (currentFilters.isEmpty()) null else currentFilters)
        petAdapter.updatePosts(posts)
    }
    
    override fun onResume() {
        super.onResume()
        loadPosts()
    }
}