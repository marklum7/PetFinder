package com.example.myapplication.data

import android.graphics.Bitmap

data class PetPostWithImages(
    val petPost: PetPost,
    val images: List<Bitmap>
)