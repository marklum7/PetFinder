package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.example.myapplication.data.DatabaseHelper
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private var userEmail: String? = null
    private var userRole: String? = null

    fun getUserRole(): String? {
        return userRole
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    
        // Get user data from intent
        userEmail = intent.getStringExtra("USER_EMAIL")
        userRole = intent.getStringExtra("USER_ROLE")
    
        setSupportActionBar(binding.toolbar)
        
        // Set title based on user role
        supportActionBar?.title = "Привет, $userEmail ($userRole)"
    
        // Скрываем fab
        binding.fab.visibility = View.GONE
    
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        
        // Если пользователь является администратором, покажем админ-панель
        if (userRole == "admin") {
            navController.navigate(R.id.adminPanelFragment)
        }
        
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        
        // Показываем опцию админ-панели только для админа
        menu.findItem(R.id.action_admin_panel)?.isVisible = userRole == DatabaseHelper.ROLE_ADMIN
        
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                // Handle settings action
                true
            }
            R.id.action_admin_panel -> {
                // Переход к админ-панели
                findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.adminPanelFragment)
                true
            }
            R.id.action_logout -> {
                // Handle logout action
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}