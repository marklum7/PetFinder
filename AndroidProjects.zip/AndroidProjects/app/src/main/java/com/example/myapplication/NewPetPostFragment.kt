package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication.data.DatabaseHelper
import com.example.myapplication.data.PetPost
import com.google.android.material.textfield.TextInputEditText
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.widget.ImageView 
    
class NewPetPostFragment : Fragment() {

    private lateinit var rgPostType: RadioGroup
    private lateinit var rbLostPet: RadioButton
    private lateinit var rbFoundPet: RadioButton
    private lateinit var etPetName: TextInputEditText
    private lateinit var etPetBreed: TextInputEditText
    private lateinit var etPetAge: TextInputEditText
    private lateinit var etPetColor: TextInputEditText
    private lateinit var etSpecialMarks: TextInputEditText
    private lateinit var etLocationAddress: TextInputEditText
    private lateinit var btnAddImage: Button
    private lateinit var imageContainer: LinearLayout
    private lateinit var btnSubmitPost: Button
    private lateinit var btnPickLocation: Button
    
    private var selectedImages = mutableListOf<Bitmap>()
    private var locationLat = 0.0
    private var locationLng = 0.0
    private lateinit var dbHelper: DatabaseHelper
    
    companion object {
        private const val REQUEST_IMAGE_PICK = 1001
    }
    
    override fun onCreateView(
        inflater: LayoutInflater, 
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_new_pet_post, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        dbHelper = DatabaseHelper(requireContext())
        
        // Инициализация views
        rgPostType = view.findViewById(R.id.rgPostType)
        rbLostPet = view.findViewById(R.id.rbLostPet)
        rbFoundPet = view.findViewById(R.id.rbFoundPet)
        etPetName = view.findViewById(R.id.etPetName)
        etPetBreed = view.findViewById(R.id.etPetBreed)
        etPetAge = view.findViewById(R.id.etPetAge)
        etPetColor = view.findViewById(R.id.etPetColor)
        etSpecialMarks = view.findViewById(R.id.etSpecialMarks)
        etLocationAddress = view.findViewById(R.id.etLocationAddress)
        btnAddImage = view.findViewById(R.id.btnAddImage)
        imageContainer = view.findViewById(R.id.imageContainer)
        btnSubmitPost = view.findViewById(R.id.btnSubmitPost)
        btnPickLocation = view.findViewById(R.id.btnPickLocation)
        
        // Настройка выбора изображений
        btnAddImage.setOnClickListener {
            if (selectedImages.size >= 5) {
                Toast.makeText(context, "Максимум 5 изображений", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_IMAGE_PICK)
        }
        
        // Настройка выбора локации (поскольку мы исключили карты, просто показываем уведомление)
        btnPickLocation.setOnClickListener {
            Toast.makeText(context, "Координаты установлены", Toast.LENGTH_SHORT).show()
            locationLat = 0.0  // Используем дефолтные значения
            locationLng = 0.0
        }
        
        // Настройка кнопки отправки
        btnSubmitPost.setOnClickListener {
            submitPost()
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    val inputStream: InputStream? = context?.contentResolver?.openInputStream(uri)
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 500, 500 * bitmap.height / bitmap.width, true)
                    selectedImages.add(resizedBitmap)
                    addImageToContainer(resizedBitmap)
                } catch (e: Exception) {
                    Toast.makeText(context, "Ошибка загрузки изображения", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun addImageToContainer(bitmap: Bitmap) {
        val imageView = ImageView(context)
        val params = LinearLayout.LayoutParams(300, 300)
        params.setMargins(0, 0, 16, 0)
        imageView.layoutParams = params
        imageView.setImageBitmap(bitmap)
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        
        imageView.setOnClickListener {
            val index = imageContainer.indexOfChild(imageView)
            if (index >= 0) {
                selectedImages.removeAt(index)
                imageContainer.removeViewAt(index)
            }
        }
        
        imageContainer.addView(imageView)
    }
    
    private fun submitPost() {
        val postType = if (rbLostPet.isChecked) "Потерян" else "Найден"
        val petName = etPetName.text.toString().trim()
        val petBreed = etPetBreed.text.toString().trim()
        val petAge = etPetAge.text.toString().trim()
        val petColor = etPetColor.text.toString().trim()
        val specialMarks = etSpecialMarks.text.toString().trim()
        val locationAddress = etLocationAddress.text.toString().trim()
        
        if (petBreed.isEmpty() || petColor.isEmpty() || locationAddress.isEmpty()) {
            Toast.makeText(context, "Заполните обязательные поля", Toast.LENGTH_SHORT).show()
            return
        }
        
        val userId = 1 // В реальном приложении получайте ID пользователя из сессии
        
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        
        val petPost = PetPost(
            postType = postType,
            petName = if (petName.isEmpty()) null else petName,
            petAge = if (petAge.isEmpty()) null else petAge,
            petBreed = petBreed,
            petColor = petColor,
            specialMarks = if (specialMarks.isEmpty()) null else specialMarks,
            locationLat = locationLat,
            locationLng = locationLng,
            locationAddress = locationAddress,
            datePosted = currentDate,
            userId = userId
        )
        
        val postId = dbHelper.createPetPost(petPost, selectedImages)
        
        if (postId != -1L) {
            Toast.makeText(context, "Объявление успешно создано", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        } else {
            Toast.makeText(context, "Ошибка при создании объявления", Toast.LENGTH_SHORT).show()
        }
    }
}