package com.example.myapplication

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.DatabaseHelper
import com.example.myapplication.data.User

class UserAdapter(
    private var users: List<User>,
    private val onUserAction: (Int, String) -> Unit // userId, action
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvUserName: TextView = itemView.findViewById(R.id.tvUserName)
        val tvUserRole: TextView = itemView.findViewById(R.id.tvUserRole)
        val tvUserPostsCount: TextView = itemView.findViewById(R.id.tvUserPostsCount)
        val tvUserStatus: TextView = itemView.findViewById(R.id.tvUserStatus)
        val btnBlockUser: Button = itemView.findViewById(R.id.btnBlockUser)
        val btnUnblockUser: Button = itemView.findViewById(R.id.btnUnblockUser)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]
        
        holder.tvUserName.text = user.email
        holder.tvUserRole.text = "Роль: ${user.role}"
        holder.tvUserPostsCount.text = "Объявлений: ${user.postsCount}"
        
        // Настройка статуса
        if (user.status == DatabaseHelper.USER_STATUS_BLOCKED) {
            holder.tvUserStatus.text = "Заблокирован"
            holder.tvUserStatus.setBackgroundResource(R.drawable.status_background)
            (holder.tvUserStatus.background as GradientDrawable).setColor(
                ContextCompat.getColor(holder.itemView.context, android.R.color.holo_red_light)
            )
            holder.btnBlockUser.visibility = View.GONE
            holder.btnUnblockUser.visibility = View.VISIBLE
        } else {
            holder.tvUserStatus.text = "Активен"
            holder.tvUserStatus.setBackgroundResource(R.drawable.status_background)
            (holder.tvUserStatus.background as GradientDrawable).setColor(
                ContextCompat.getColor(holder.itemView.context, android.R.color.holo_green_light)
            )
            holder.btnBlockUser.visibility = View.VISIBLE
            holder.btnUnblockUser.visibility = View.GONE
        }
        
        // Обработчики нажатий
        holder.btnBlockUser.setOnClickListener {
            onUserAction(user.id, "block")
        }
        
        holder.btnUnblockUser.setOnClickListener {
            onUserAction(user.id, "unblock")
        }
    }

    override fun getItemCount() = users.size

    fun updateUsers(newUsers: List<User>) {
        users = newUsers
        notifyDataSetChanged()
    }
}