package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.PetPostWithImages

class PetPostAdapter(
    private var petPosts: List<PetPostWithImages>,
    private val onItemClick: (PetPostWithImages) -> Unit
) : RecyclerView.Adapter<PetPostAdapter.PetViewHolder>() {
    
    class PetViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val petImage: ImageView = view.findViewById(R.id.petThumbnail)
        val petName: TextView = view.findViewById(R.id.tvPetName)
        val petType: TextView = view.findViewById(R.id.tvPostType)
        val petBreed: TextView = view.findViewById(R.id.tvPetBreed)
        val datePosted: TextView = view.findViewById(R.id.tvDatePosted)
        val location: TextView = view.findViewById(R.id.tvLocation)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pet_post, parent, false)
        return PetViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        val post = petPosts[position]
        
        // Set image if available
        if (post.images.isNotEmpty()) {
            holder.petImage.setImageBitmap(post.images[0])
        } else {
            holder.petImage.setImageResource(R.drawable.pet_placeholder)
        }
        
        // Set pet details
        holder.petName.text = post.petPost.petName ?: "Безымянный"
        holder.petType.text = post.petPost.postType
        holder.petBreed.text = post.petPost.petBreed
        holder.datePosted.text = "Дата: ${post.petPost.datePosted}"
        holder.location.text = "Адрес: ${post.petPost.locationAddress}"
        
        // Set click listener
        holder.itemView.setOnClickListener {
            onItemClick(post)
        }
    }
    
    override fun getItemCount() = petPosts.size
    
    fun updatePosts(newPosts: List<PetPostWithImages>) {
        this.petPosts = newPosts
        notifyDataSetChanged()
    }
}