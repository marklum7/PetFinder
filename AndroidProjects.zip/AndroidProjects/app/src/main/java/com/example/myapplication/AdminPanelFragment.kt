package com.example.myapplication

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController  // Добавьте этот импорт
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.DatabaseHelper
import com.example.myapplication.data.User
import com.google.android.material.tabs.TabLayout

class AdminPanelFragment : Fragment() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var tabLayout: TabLayout
    private lateinit var tvNoData: TextView
    
    // Адаптеры для списков
    private lateinit var userAdapter: UserAdapter
    private lateinit var allPostsAdapter: PetAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_panel, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        dbHelper = DatabaseHelper(requireContext())
        
        // Инициализация компонентов
        recyclerView = view.findViewById(R.id.recyclerViewAdmin)
        tabLayout = view.findViewById(R.id.tabLayoutAdmin)
        tvNoData = view.findViewById(R.id.tvNoData)
        
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        
        // Инициализация адаптеров
        userAdapter = UserAdapter(emptyList()) { userId, action ->
            // Обработка действий с пользователем
            when (action) {
                "block" -> {
                    dbHelper.blockUser(userId)
                    loadUsers() // Перезагрузка списка
                    Toast.makeText(requireContext(), "Пользователь заблокирован", Toast.LENGTH_SHORT).show()
                }
                "unblock" -> {
                    dbHelper.unblockUser(userId)
                    loadUsers() // Перезагрузка списка
                    Toast.makeText(requireContext(), "Пользователь разблокирован", Toast.LENGTH_SHORT).show()
                }
            }
        }
        
        
        allPostsAdapter = PetAdapter(
            emptyList(),
            { postId -> // Клик по посту
                val bundle = Bundle().apply {
                    putLong("post_id", postId)
                }
                findNavController().navigate(R.id.petDetailFragment, bundle)
            },
            true, // Это админ
            { postId -> // Удаление поста
                AlertDialog.Builder(requireContext())
                    .setTitle("Удаление объявления")
                    .setMessage("Вы действительно хотите удалить это объявление?")
                    .setPositiveButton("Да") { _, _ ->
                        if (dbHelper.deletePost(postId)) {
                            loadAllPosts() // Перезагрузка списка
                            Toast.makeText(requireContext(), "Объявление удалено", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(requireContext(), "Ошибка удаления", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        )
        
        // Настройка табов
        setupTabs()
        
        // По умолчанию загружаем список пользователей
        loadUsers()
    }
    
    private fun setupTabs() {
        with(tabLayout) {
            addTab(newTab().setText("Пользователи"))
            addTab(newTab().setText("Все объявления"))
            
            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    when (tab.position) {
                        0 -> loadUsers()
                        1 -> loadAllPosts()
                    }
                }
                override fun onTabUnselected(tab: TabLayout.Tab) {}
                override fun onTabReselected(tab: TabLayout.Tab) {}
            })
        }
    }
    
    private fun loadUsers() {
        val users = dbHelper.getAllUsers()
        if (users.isNotEmpty()) {
            userAdapter.updateUsers(users)
            recyclerView.adapter = userAdapter
            tvNoData.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        } else {
            tvNoData.text = "Нет зарегистрированных пользователей"
            tvNoData.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        }
    }
    
    private fun loadAllPosts() {
        val posts = dbHelper.getAllPetPosts()
        if (posts.isNotEmpty()) {
            allPostsAdapter.updatePosts(posts)
            recyclerView.adapter = allPostsAdapter
            tvNoData.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        } else {
            tvNoData.text = "Нет объявлений"
            tvNoData.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        }
    }
}