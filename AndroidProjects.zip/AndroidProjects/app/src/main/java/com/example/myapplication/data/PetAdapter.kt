package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.PetPostWithImages

class PetAdapter(
    private var petPosts: List<PetPostWithImages>, // Renamed to match usage in methods
    private val onItemClick: (Long) -> Unit,
    private val isAdmin: Boolean = false,
    private val onDeleteClick: ((Long) -> Unit)? = null
) : RecyclerView.Adapter<PetAdapter.PetViewHolder>() {

    class PetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val petThumbnail: ImageView = itemView.findViewById(R.id.petThumbnail)
        val tvPostType: TextView = itemView.findViewById(R.id.tvPostType)
        val tvPetName: TextView = itemView.findViewById(R.id.tvPetName)
        val tvPetBreed: TextView = itemView.findViewById(R.id.tvPetBreed)
        val tvDatePosted: TextView = itemView.findViewById(R.id.tvDatePosted)
        val tvLocation: TextView = itemView.findViewById(R.id.tvLocation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder { // Changed to PetViewHolder
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pet_post, parent, false)
            
        // Если это админ и кнопка существует, покажем её
        if (isAdmin) {
            view.findViewById<ImageButton>(R.id.btnDeletePost)?.visibility = View.VISIBLE
        }
        
        return PetViewHolder(view) // Changed to PetViewHolder
    }

    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        val post = petPosts[position]
        
        // Устанавливаем тип объявления
        holder.tvPostType.text = post.petPost.postType
        
        // Устанавливаем имя питомца
        holder.tvPetName.text = post.petPost.petName ?: "Неизвестно"
        
        // Устанавливаем породу
        holder.tvPetBreed.text = post.petPost.petBreed
        
        // Устанавливаем дату
        holder.tvDatePosted.text = "Дата: ${post.petPost.datePosted}"
        
        // Устанавливаем местоположение
        holder.tvLocation.text = "Место: ${post.petPost.locationAddress}"
        
        // Устанавливаем изображение, если есть
        if (post.images.isNotEmpty()) {
            holder.petThumbnail.setImageBitmap(post.images[0])
        } else {
            holder.petThumbnail.setImageResource(R.drawable.pet_placeholder)
        }
        
        holder.itemView.findViewById<ImageButton>(R.id.btnDeletePost)?.setOnClickListener {
            onDeleteClick?.invoke(post.petPost.id)
        }
        
        // Устанавливаем обработчик клика
        holder.itemView.setOnClickListener {
            onItemClick(post.petPost.id)
        }
    }

    override fun getItemCount() = petPosts.size

    fun updatePosts(newPosts: List<PetPostWithImages>) {
        petPosts = newPosts
        notifyDataSetChanged()
    }
}