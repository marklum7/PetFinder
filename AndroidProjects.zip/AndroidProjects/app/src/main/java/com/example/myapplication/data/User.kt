package com.example.myapplication.data

data class User(
    val id: Int,
    val email: String,
    val firstName: String = "",
    val lastName: String = "",
    val phone: String = "",
    val role: String,
    val postsCount: Int = 0,
    val status: String = "active"
)