package com.example.myapplication.data

data class PetPost(
    val id: Long = 0,
    val postType: String,
    val petName: String?,
    val petAge: String?,
    val petBreed: String,
    val petColor: String,
    val specialMarks: String?,
    val locationLat: Double,
    val locationLng: Double,
    val locationAddress: String,
    val datePosted: String,
    val userId: Int
)