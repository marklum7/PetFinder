package com.example.myapplication.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.util.*

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "PetFinderDatabase"
        private const val DATABASE_VERSION = 5

        // User table
        private const val TABLE_USERS = "users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_EMAIL = "email"
        private const val COLUMN_PASSWORD = "password"
        private const val COLUMN_ROLE = "role"
        private const val COLUMN_FIRST_NAME = "first_name"
        private const val COLUMN_LAST_NAME = "last_name"
        private const val COLUMN_PHONE = "phone"
        private const val COLUMN_STATUS = "status" // active or blocked
        const val USER_STATUS_ACTIVE = "active"
        const val USER_STATUS_BLOCKED = "blocked"

        // Pet posts table
        private const val TABLE_PET_POSTS = "pet_posts"
        private const val COLUMN_POST_ID = "post_id"
        private const val COLUMN_POST_TYPE = "post_type" // LOST or FOUND
        private const val COLUMN_PET_NAME = "pet_name"
        private const val COLUMN_PET_AGE = "pet_age"
        private const val COLUMN_PET_BREED = "pet_breed"
        private const val COLUMN_PET_COLOR = "pet_color"
        private const val COLUMN_SPECIAL_MARKS = "special_marks"
        private const val COLUMN_LOCATION_LAT = "location_lat"
        private const val COLUMN_LOCATION_LNG = "location_lng"
        private const val COLUMN_LOCATION_ADDRESS = "location_address"
        private const val COLUMN_DATE_POSTED = "date_posted"
        private const val COLUMN_USER_ID = "user_id"
        
        // Pet images table
        private const val TABLE_PET_IMAGES = "pet_images"
        private const val COLUMN_IMAGE_ID = "image_id"
        private const val COLUMN_IMAGE_DATA = "image_data"
        private const val COLUMN_POST_ID_FK = "post_id"

        // Roles
        const val ROLE_ADMIN = "Администрация"
        const val ROLE_VOLUNTEER = "Волонтёры"
        const val ROLE_PET_OWNER = "Владельцы животных"
        
        // Post types
        const val POST_TYPE_LOST = "Потерян"
        const val POST_TYPE_FOUND = "Найден"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        val createUsersTableQuery = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_EMAIL TEXT UNIQUE NOT NULL,
                $COLUMN_PASSWORD TEXT NOT NULL,
                $COLUMN_FIRST_NAME TEXT DEFAULT '',
                $COLUMN_LAST_NAME TEXT DEFAULT '',
                $COLUMN_PHONE TEXT DEFAULT '',
                $COLUMN_ROLE TEXT NOT NULL,
                $COLUMN_STATUS TEXT DEFAULT '$USER_STATUS_ACTIVE'
            )
        """.trimIndent()
        db.execSQL(createUsersTableQuery)
        
        // Create pet posts table   
        val createPostsTableQuery = """
            CREATE TABLE $TABLE_PET_POSTS (
                $COLUMN_POST_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_POST_TYPE TEXT NOT NULL,
                $COLUMN_PET_NAME TEXT,
                $COLUMN_PET_AGE TEXT,
                $COLUMN_PET_BREED TEXT,
                $COLUMN_PET_COLOR TEXT,
                $COLUMN_SPECIAL_MARKS TEXT,
                $COLUMN_LOCATION_LAT REAL,
                $COLUMN_LOCATION_LNG REAL,
                $COLUMN_LOCATION_ADDRESS TEXT,
                $COLUMN_DATE_POSTED TEXT NOT NULL,
                $COLUMN_USER_ID INTEGER NOT NULL,
                FOREIGN KEY($COLUMN_USER_ID) REFERENCES $TABLE_USERS($COLUMN_ID)
            )
        """.trimIndent()
        db.execSQL(createPostsTableQuery)
        
        // Create pet images table
        val createImagesTableQuery = """
            CREATE TABLE $TABLE_PET_IMAGES (
                $COLUMN_IMAGE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_IMAGE_DATA TEXT NOT NULL,
                $COLUMN_POST_ID_FK INTEGER NOT NULL,
                FOREIGN KEY($COLUMN_POST_ID_FK) REFERENCES $TABLE_PET_POSTS($COLUMN_POST_ID) ON DELETE CASCADE
            )
        """.trimIndent()
        db.execSQL(createImagesTableQuery)
        
        // Add default users
        addDefaultUsers(db)
    }

    fun deletePost(postId: Long): Boolean {
        val db = this.writableDatabase
        val result = db.delete(
            TABLE_PET_POSTS,
            "$COLUMN_POST_ID = ?",
            arrayOf(postId.toString())
        )
        db.close()
        return result > 0
    }

    fun blockUser(userId: Int): Boolean {
        val db = this.writableDatabase
        
        // Check if status column exists
        val cursor = db.rawQuery("PRAGMA table_info($TABLE_USERS)", null)
        val columnNames = mutableListOf<String>()
        while (cursor.moveToNext()) {
            columnNames.add(cursor.getString(cursor.getColumnIndexOrThrow("name")))
        }
        cursor.close()
        
        val hasStatusColumn = columnNames.contains(COLUMN_STATUS)
        
        // If column doesn't exist, add it first
        if (!hasStatusColumn) {
            try {
                db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_STATUS TEXT DEFAULT '$USER_STATUS_ACTIVE'")
            } catch (e: Exception) {
                db.close()
                return false
            }
        }
        
        // Now update the status
        val values = ContentValues().apply {
            put(COLUMN_STATUS, USER_STATUS_BLOCKED)
        }
        val result = db.update(
            TABLE_USERS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(userId.toString())
        )
        db.close()
        return result > 0
    }
    
    fun unblockUser(userId: Int): Boolean {
        val db = this.writableDatabase
        
        // Check if status column exists
        val cursor = db.rawQuery("PRAGMA table_info($TABLE_USERS)", null)
        val columnNames = mutableListOf<String>()
        while (cursor.moveToNext()) {
            columnNames.add(cursor.getString(cursor.getColumnIndexOrThrow("name")))
        }
        cursor.close()
        
        val hasStatusColumn = columnNames.contains(COLUMN_STATUS)
        
        // If column doesn't exist, add it first
        if (!hasStatusColumn) {
            try {
                db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_STATUS TEXT DEFAULT '$USER_STATUS_ACTIVE'")
            } catch (e: Exception) {
                db.close()
                return false
            }
        }
        
        // Now update the status
        val values = ContentValues().apply {
            put(COLUMN_STATUS, USER_STATUS_ACTIVE)
        }
        val result = db.update(
            TABLE_USERS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(userId.toString())
        )
        db.close()
        return result > 0
    }
    
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 4) {
            // Добавляем колонку телефона к существующей таблице
            try {
                db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_PHONE TEXT DEFAULT ''")
            } catch (e: Exception) {
                // Если колонка уже существует или другая ошибка, пересоздаем таблицы
                db.execSQL("DROP TABLE IF EXISTS $TABLE_PET_IMAGES")
                db.execSQL("DROP TABLE IF EXISTS $TABLE_PET_POSTS")
                db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
                onCreate(db)
            }
        }
        
        // Добавляем колонку статуса для версии 5
        if (oldVersion < 5) {
            try {
                db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_STATUS TEXT DEFAULT '$USER_STATUS_ACTIVE'")
            } catch (e: Exception) {
                // Если ошибка, пересоздаем таблицы
                db.execSQL("DROP TABLE IF EXISTS $TABLE_PET_IMAGES")
                db.execSQL("DROP TABLE IF EXISTS $TABLE_PET_POSTS")
                db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
                onCreate(db)
            }
        }
    }

    private fun addDefaultUsers(db: SQLiteDatabase) {
        // Add admin user
        val adminValues = ContentValues().apply {
            put(COLUMN_EMAIL, "admin@example.com")
            put(COLUMN_PASSWORD, "admin123")
            put(COLUMN_ROLE, ROLE_ADMIN)
        }
        db.insert(TABLE_USERS, null, adminValues)
        
        // Add regular user
        val userValues = ContentValues().apply {
            put(COLUMN_EMAIL, "user@example.com")
            put(COLUMN_PASSWORD, "user123")
            put(COLUMN_ROLE, ROLE_PET_OWNER)
        }
        db.insert(TABLE_USERS, null, userValues)
    }

    fun registerUser(email: String, password: String, phone: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_EMAIL, email)
            put(COLUMN_PASSWORD, password)
            put(COLUMN_PHONE, phone)  // Сохраняем номер телефона
            put(COLUMN_ROLE, ROLE_PET_OWNER) // Default role for new users
        }
        
        val result = db.insert(TABLE_USERS, null, values)
        db.close()
        return result != -1L
    }

    fun loginUser(email: String, password: String): User? {
        val db = this.readableDatabase
        val selection = "$COLUMN_EMAIL = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(email, password)
        val cursor = db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null)
        
        var user: User? = null
        
        if (cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val userEmail = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL))
            val role = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ROLE))
            
            // Получаем статус пользователя
            var status = USER_STATUS_ACTIVE
            try {
                status = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS))
            } catch (e: Exception) {
                // Игнорируем ошибку, если колонка не найдена
            }
            
            // Проверяем, не заблокирован ли пользователь
            if (status == USER_STATUS_BLOCKED) {
                return null // Заблокированные пользователи не могут войти
            }
            
            var phone = ""
            try {
                phone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE))
            } catch (e: Exception) {
                // Игнорируем ошибку, если колонка не найдена
            }
            
            user = User(id, userEmail, "", "", phone, role, 0, status)
        }
        
        cursor.close()
        db.close()
        return user
    }
    
    // Pet post methods
    fun createPetPost(post: PetPost, images: List<Bitmap>): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_POST_TYPE, post.postType)
            put(COLUMN_PET_NAME, post.petName)
            put(COLUMN_PET_AGE, post.petAge)
            put(COLUMN_PET_BREED, post.petBreed)
            put(COLUMN_PET_COLOR, post.petColor)
            put(COLUMN_SPECIAL_MARKS, post.specialMarks)
            put(COLUMN_LOCATION_LAT, post.locationLat)
            put(COLUMN_LOCATION_LNG, post.locationLng)
            put(COLUMN_LOCATION_ADDRESS, post.locationAddress)
            put(COLUMN_DATE_POSTED, post.datePosted)
            put(COLUMN_USER_ID, post.userId)
        }
        
        val postId = db.insert(TABLE_PET_POSTS, null, values)
        
        // Save images (up to 5)
        if (postId != -1L) {
            val imagesToSave = if (images.size > 5) images.take(5) else images
            for (image in imagesToSave) {
                val imageValues = ContentValues().apply {
                    put(COLUMN_IMAGE_DATA, bitmapToString(image))
                    put(COLUMN_POST_ID_FK, postId)
                }
                db.insert(TABLE_PET_IMAGES, null, imageValues)
            }
        }
        
        db.close()
        return postId
    }
    
    fun getAllPetPosts(filters: Map<String, Any>? = null): List<PetPostWithImages> {
        val db = this.readableDatabase
        val posts = mutableListOf<PetPostWithImages>()
        
        // Build query with filters
        var selection = ""
        val selectionArgs = mutableListOf<String>()
        
        if (filters != null) {
            val selectionCriteria = mutableListOf<String>()
            
            filters["postType"]?.let {
                selectionCriteria.add("$COLUMN_POST_TYPE = ?")
                selectionArgs.add(it.toString())
            }
            
            filters["breed"]?.let {
                selectionCriteria.add("$COLUMN_PET_BREED LIKE ?")
                selectionArgs.add("%${it}%")
            }
            
            filters["color"]?.let {
                selectionCriteria.add("$COLUMN_PET_COLOR LIKE ?")
                selectionArgs.add("%${it}%")
            }
            
            filters["dateFrom"]?.let {
                selectionCriteria.add("$COLUMN_DATE_POSTED >= ?")
                selectionArgs.add(it.toString())
            }
            
            filters["dateTo"]?.let {
                selectionCriteria.add("$COLUMN_DATE_POSTED <= ?")
                selectionArgs.add(it.toString())
            }
            
            if (selectionCriteria.isNotEmpty()) {
                selection = selectionCriteria.joinToString(" AND ")
            }
        }
        
        // Query for posts
        val cursor = db.query(
            TABLE_PET_POSTS,
            null,
            if (selection.isEmpty()) null else selection,
            if (selectionArgs.isEmpty()) null else selectionArgs.toTypedArray(),
            null,
            null,
            "$COLUMN_DATE_POSTED DESC"
        )
        
        while (cursor.moveToNext()) {
            val post = extractPostFromCursor(cursor)
            val images = getImagesForPost(db, post.id)
            posts.add(PetPostWithImages(post, images))
        }
        
        cursor.close()
        db.close()
        return posts
    }
    
    fun getPetPostById(postId: Long): PetPostWithImages? {
        val db = this.readableDatabase
        val selection = "$COLUMN_POST_ID = ?"
        val selectionArgs = arrayOf(postId.toString())
        
        val cursor = db.query(TABLE_PET_POSTS, null, selection, selectionArgs, null, null, null)
        
        var postWithImages: PetPostWithImages? = null
        
        if (cursor.moveToFirst()) {
            val post = extractPostFromCursor(cursor)
            val images = getImagesForPost(db, postId)
            postWithImages = PetPostWithImages(post, images)
        }
        
        cursor.close()
        db.close()
        return postWithImages
    }
    
    private fun extractPostFromCursor(cursor: Cursor): PetPost {
        return PetPost(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_POST_ID)),
            postType = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_POST_TYPE)),
            petName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PET_NAME)),
            petAge = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PET_AGE)),
            petBreed = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PET_BREED)),
            petColor = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PET_COLOR)),
            specialMarks = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SPECIAL_MARKS)),
            locationLat = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_LOCATION_LAT)),
            locationLng = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_LOCATION_LNG)),
            locationAddress = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION_ADDRESS)),
            datePosted = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE_POSTED)),
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID))
        )
    }
    
    private fun getImagesForPost(db: SQLiteDatabase, postId: Long): List<Bitmap> {
        val images = mutableListOf<Bitmap>()
        val selection = "$COLUMN_POST_ID_FK = ?"
        val selectionArgs = arrayOf(postId.toString())
        
        val cursor = db.query(TABLE_PET_IMAGES, null, selection, selectionArgs, null, null, null)
        
        while (cursor.moveToNext()) {
            val imageStr = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_IMAGE_DATA))
            val bitmap = stringToBitmap(imageStr)
            bitmap?.let { images.add(it) }
        }
        
        cursor.close()
        return images
    }

    fun getAllBreeds(): List<String> {
        val breeds = mutableListOf<String>()
        val db = this.readableDatabase
        
        val query = "SELECT DISTINCT $COLUMN_PET_BREED FROM $TABLE_PET_POSTS ORDER BY $COLUMN_PET_BREED ASC"
        val cursor = db.rawQuery(query, null)
        
        while (cursor.moveToNext()) {
            val breed = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PET_BREED))
            if (!breed.isNullOrEmpty()) {
                breeds.add(breed)
            }
        }
        
        cursor.close()
        db.close()
        return breeds
    }

    fun getAllUsers(): List<User> {
        val users = mutableListOf<User>()
        val db = this.readableDatabase
        
        // Проверяем наличие колонки статуса
        val metaCursor = db.rawQuery("PRAGMA table_info($TABLE_USERS)", null)
        val columnNames = mutableListOf<String>()
        while (metaCursor.moveToNext()) {
            columnNames.add(metaCursor.getString(metaCursor.getColumnIndexOrThrow("name")))
        }
        metaCursor.close()
        
        val hasStatusColumn = columnNames.contains(COLUMN_STATUS)
        
        // Составляем запрос в зависимости от наличия колонки статуса
        val query = if (hasStatusColumn) {
            """
                SELECT u.id, u.email, u.role, u.status, COUNT(p.$COLUMN_POST_ID) as posts_count 
                FROM $TABLE_USERS u 
                LEFT JOIN $TABLE_PET_POSTS p ON u.$COLUMN_ID = p.$COLUMN_USER_ID 
                GROUP BY u.$COLUMN_ID
            """
        } else {
            """
                SELECT u.id, u.email, u.role, COUNT(p.$COLUMN_POST_ID) as posts_count 
                FROM $TABLE_USERS u 
                LEFT JOIN $TABLE_PET_POSTS p ON u.$COLUMN_ID = p.$COLUMN_USER_ID 
                GROUP BY u.$COLUMN_ID
            """
        }
        
        val cursor = db.rawQuery(query, null)
        
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL))
            val role = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ROLE))
            val postsCount = cursor.getInt(cursor.getColumnIndexOrThrow("posts_count"))
            
            // Получаем статус, если колонка существует
            val status = if (hasStatusColumn) {
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS))
            } else {
                USER_STATUS_ACTIVE
            }
            
            users.add(User(id, email, "", "", "", role, postsCount, status))
        }
        
        cursor.close()
        db.close()
        
        return users
    }

    // Utility methods for image conversion
    private fun bitmapToString(bitmap: Bitmap): String {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos)
        val bytes = baos.toByteArray()
        return Base64.encodeToString(bytes, Base64.DEFAULT)
    }
    
    private fun stringToBitmap(encodedString: String): Bitmap? {
        return try {
            val encodedByte = Base64.decode(encodedString, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(encodedByte, 0, encodedByte.size)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}